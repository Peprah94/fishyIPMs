This is the Zenodo repository for the manuscript "A flexible Bayesian approach for estimating survival probabilities from age-at-harvest data" by Skelly et al.
The three folders contained within (and listed below) refer to the simulation study and two real-world case studies (using bobcat and paddlefish data) within our manuscript.

Bobcat
  * This folder contains all files and code for the bobcat survival study

Paddlefish
  * This folder contains all files and code for the paddlefish survival study
  
Simulations
  * This folder contains all files and code for the simulation study